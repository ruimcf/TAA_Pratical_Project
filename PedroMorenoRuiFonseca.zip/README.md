# TAA_Pratical_Project
usage:

Horizontal or grid partition:

./example

with zoom for ascii print (needs to be a positive integer)

./example \<zoom>

guard visibility (index goes from 0 to number of vertices given - 1)

./example \<zoom> "guard" \<vertex_index>

solve minimum vertex guard (k is the number of guards each face must be seen by)

./example \<zoom> "mvg" \<k>
